import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { environment } from 'src/environments/environment';
import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { HomeComponent } from './home/home.component';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { BooksListComponent } from './books-list/books-list.component';
import { BookDialogComponent } from './book-dialog/book-dialog.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BookService } from './services/book.service';
import { HeaderComponent } from './shared/header/header.component';
import { LoginComponent } from './login/login.component';
import { AngularFireAuthModule } from "@angular/fire/auth";
import { AuthService } from './services/auth.service';
import { FooterComponent } from './shared/footer/footer.component';
import { UtilsService } from './services/utils.service';
import { CategoryService } from './services/category.service';
import { AgGridModule } from 'ag-grid-angular';
import { AuthenticatedGuard } from './services/auth-gaurd-service';
import { PreventUnsavedChangesGuard } from './services/prevent-changes.guard.service';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BooksListComponent,
    BookDialogComponent,
    LoginComponent,
  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireAuthModule,
    AngularFirestoreModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    SharedModule,
    AgGridModule.withComponents([])
  ],
  providers: [BookService, AuthService, CategoryService, { provide: LocationStrategy, useClass: HashLocationStrategy },],
  entryComponents: [BookDialogComponent],
  bootstrap: [AppComponent],
})
export class AppModule { }
