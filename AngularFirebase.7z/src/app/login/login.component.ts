import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { AngularFireAuth } from '@angular/fire/auth';
import { Router } from '@angular/router';
import { AppConstants } from '../shared/constants';
import { UtilsService } from '../services/utils.service';
declare let $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  username: any;
  password: any;
  loginForm: FormGroup;
  errorMessage: string = "";
  isError : boolean = false
  constructor(private fb: FormBuilder, public authService: AuthService, private router: Router, private utilsService:UtilsService) { 
    let metaData = [{ name: 'author', content: 'AMAZATIC' }, { name: 'keywords', content: 'Book store,Login, Manage books' }, { name: 'description', content: 'User login' }]
    this.utilsService.addMetaTags(metaData);
    this.utilsService.setTitleToPage("Book Store - Login");
    this.utilsService.smoothScrollToTop();
  }

  /**
  * @function ngOnInit()
  * @param none
  * @description This method is used creating login form and removing session data when user comes on this page.
  * @author Ashish Hulwan
  */
  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.pattern(AppConstants.emailRegex)]],
      password: ['', Validators.required]
    });
  
    sessionStorage.removeItem('USER');
  }

  /**
  * @function login()
  * @param none
  * @description This method is used for login user using email password and navigate to home page.
  * @author Ashish Hulwan
  */
  login() {
    this.isError = false
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.getRawValue()).then(res => {
        console.log("Login Result", res);
        this.utilsService.showSnackBar(this.loginForm.value.email +" you logged in successfully.");
        this.loginForm.reset();
        this.router.navigate(['home']);
      }, error => {
        console.log("Failed", error)
        if(error.code === "auth/user-not-found"){
          this.isError = true;
          this.errorMessage = "Please enter correct username and password."
        }
      })
    } else {
      $('input.ng-invalid').first().focus();
    }

  }
}
