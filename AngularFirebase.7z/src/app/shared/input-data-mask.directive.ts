import { Directive, HostListener, ElementRef } from '@angular/core';
import { NgControl, FormGroupDirective, FormControlDirective } from '@angular/forms';


@Directive({
  selector: 'input[type=text][trim] , textarea[trim]'
})
export class InputDataMaskDirective {
  constructor(private el: ElementRef, private control: NgControl) { }

  @HostListener('blur', ['$event']) onEvent($event) {
    console.log(this.el.nativeElement.value)
    let trim = this.el.nativeElement.value.trim();
    this.control.control.setValue(trim);
  }
}
