export class AppConstants {
    public static emailRegex = /^[A-Za-z0-9+_.-]+@[a-zA-Z0-9]{1,}(.+)[a-zA-Z0-9]{1,}$/ //^(?=.)^\$?(([1-9][0-9]{0,2}(,[0-9]{3})*)|[0-9]+)?(\.[0-9]{1,3})?$/
    // public static mobileNumberRegex = /^[1-9]{1}[0-9]{1,9}$/ 
    public static charRegex = "[a-zA-Z ]*"
    // public static amountWithoutDecimal = /^[0-9]*$/
    // public static amountWithDecimal = /^\s*-?\d+(\.\d{1,2})?\s*$/
    public static indianCurrencySymbol = "₹ ";
}
