import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { MaterialModule } from './material.module';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { UtilsService } from '../services/utils.service';
import { PreventUnsavedChangesGuard } from '../services/prevent-changes.guard.service';
import { AuthenticatedGuard } from '../services/auth-gaurd-service';
import { DeleteDialogComponent } from './delete-dialog/delete-dialog.component';
import { InputDataMaskDirective } from './input-data-mask.directive';
import { IndianCurrencyPipe } from './indianCurrency.pipe';
import { NotFoundComponent } from './not-found/not-found.component';

@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    DeleteDialogComponent,
    InputDataMaskDirective,
    IndianCurrencyPipe,
    NotFoundComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
    CommonModule,
    MaterialModule,
    DeleteDialogComponent,
    InputDataMaskDirective,
    IndianCurrencyPipe,
    NotFoundComponent
  ],
  providers: [AuthenticatedGuard, PreventUnsavedChangesGuard, UtilsService],
  entryComponents: [DeleteDialogComponent]
})
export class SharedModule { }
