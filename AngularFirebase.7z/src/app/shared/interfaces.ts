export interface Book {
  userEmail: string;
  author: string;
  description: string;
  name: string;
  publication: string;
  price: number;
  category: string;
  comments: string;
}
export interface Category {
  id: string;
  seqNum: number;
  code: string;
  displayName: string;
  isActive: string;
  publication: boolean;
}