import { Component, HostListener, AfterViewInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { BookService } from 'src/app/services/book.service';
import { AppConstants } from '../constants';
import { UtilsService } from 'src/app/services/utils.service';

@Component({
  selector: 'delete-dialog',
  templateUrl: './delete-dialog.component.html',
  styleUrls: ['./delete-dialog.component.scss'],
  providers: [BookService]
})

export class DeleteDialogComponent implements AfterViewInit {
  userData: any;
  charRegex = AppConstants.charRegex;
  categories = []
  constructor(private utilsService: UtilsService, private bookService: BookService,
    public dialogRef: MatDialogRef<DeleteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.userData = JSON.parse(sessionStorage.getItem("USER"))

  }

  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }
  ngAfterViewInit(): void {
    console.log("in Dialog", this.data)
  }

  ngOnInit() {

  }

  /**
  * @function deleteBook() 
  * @param none
  * @description This function is used for deleting users favourite book using id.
  * @author Ashish Hulwan
  */
  deleteBook() {
    this.bookService.deleteBook(this.data.book.id).then(result => {
      console.log("Book deleted result=", result);
      this.dialogRef.close(true)
    })
  }

}