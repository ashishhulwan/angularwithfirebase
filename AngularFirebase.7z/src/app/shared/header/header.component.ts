import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { UtilsService } from 'src/app/services/utils.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  user: any
  constructor(private router: Router, private authService: AuthService, private utilsService:UtilsService) {
    this.user = JSON.parse(sessionStorage.getItem('USER'));
  }

  ngOnInit() {
  }

  /**
  * @function logout()
  * @param none
  * @description This function is used for logging out user from system.
  * @author Ashish Hulwan
  */
  logout() {
    this.authService.logout().then(result=>{
      console.log("Login Result", result);
      sessionStorage.removeItem('USER');
      this.utilsService.showSnackBar("You logged out successfully.");
      this.router.navigate(['login']);
    })
  }

  /**
  * @function isUserLoggedIn()
  * @param none
  * @description This function is used for is user logged in or not.
  * @returns true/false
  * @author Ashish Hulwan
  */
  isUserLoggedIn(){
    this.user = JSON.parse(sessionStorage.getItem('USER'));
    if(this.user !== null){
      return true;
    }else{
      return false
    }
  }

  /**
  * @function gotoLogin(),gotoHome()
  * @param none
  * @description This methods are used for changing the routes using router object.
  * @author Ashish Hulwan
  */
  gotoLogin() {
    sessionStorage.removeItem("USER")
    this.router.navigate(['login']);
  }
  gotoHome(){
    this.router.navigate(['/home'])
  }
}
