import { Component, OnInit } from '@angular/core';
import { UtilsService } from '../services/utils.service';
import { Router } from '@angular/router';
import { BookDialogComponent } from '../book-dialog/book-dialog.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  user: any;
  username: string = ""
  constructor(private utilsService: UtilsService, private router: Router, public matDialog: MatDialog, ) {
    this.user = JSON.parse(sessionStorage.getItem('USER'));
    this.username = this.utilsService.isNonEmpty(this.user) ? this.user.email : "to Book Store";
    let metaData = [{ name: 'author', content: 'AMAZATIC' }, { name: 'keywords', content: 'Book store,Users books ,Books Home' }, { name: 'description', content: 'Manage your favourite books.' }]
    this.utilsService.addMetaTags(metaData);
    this.utilsService.setTitleToPage("Book Store - Home");
    this.utilsService.smoothScrollToTop();
  }

  ngOnInit() {
  }

  /**
  * @function isLoggedIn()
  * @param none
  * @description This function is used for checking is user logged in or not.
  * @returns true/false
  * @author Ashish Hulwan
  */
  isLoggedIn() {
    return this.utilsService.isNonEmpty(this.user) ? true : false;
  }

  /**
  * @function gotoBooks()
  * @param none
  * @description This function is used for changing the routes with Router methods.
  * @author Ashish Hulwan
  */
  gotoBooks() {
    this.router.navigate(['/books'])
  }

  /**
  * @function addUpdateBook()
  * @params mode, book
  * @description This method is used for open the dialog for book add and update with the help of mode and book data.
  * @author Ashish Hulwan
  */
  addUpdateBook(mode, book) {
    let data = {
      mode: mode,
      title: mode === "ADD" ? "Add New Book" : "Update Book Details",
      book: book
    }
    //Open the book dialog here
    let dialogRef = this.matDialog.open(BookDialogComponent, {
      data: data,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log("Book Add result=", result)
      if (result !== undefined)
        this.utilsService.showSnackBar("Your favourite book added successfuly.");
    });
  }
}
