import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { BookDialogComponent } from '../book-dialog/book-dialog.component';
import { BookService } from '../services/book.service';
import { GridOptions } from 'ag-grid-community';
import { CategoryService } from '../services/category.service';
import { UtilsService } from '../services/utils.service';
import { DeleteDialogComponent } from '../shared/delete-dialog/delete-dialog.component';

@Component({
  selector: 'app-books-list',
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.scss']
})
export class BooksListComponent implements OnInit {

  user: any;
  myBooks = [];
  books = [];
  categories = [];
  public gridOptions: GridOptions;

  constructor(public matDialog: MatDialog, private bookService: BookService, private categoryService: CategoryService, private utilsService: UtilsService) {
    this.user = JSON.parse(sessionStorage.getItem('USER'))
    this.callInConstructor([]);
    let metaData = [{ name: 'author', content: 'AMAZATIC' }, { name: 'keywords', content: 'Book store,Users books ,Users favourite books' }, { name: 'description', content: 'Users favourite book list' }]
    this.utilsService.addMetaTags(metaData);
    this.utilsService.setTitleToPage(this.user.email + " - Favourite books");
    this.utilsService.smoothScrollToTop();
  }

  /**
  * @function ngOnInit()
  * @param none
  * @description This method is implemented from angular life cycle hooks for getting favourite book and categories data.
  * @author Ashish Hulwan
  */
  ngOnInit() {
    this.getAllBooks();
    this.getMyBooks();
    this.getAllCategories();
  }

  /**
  * @function addUpdateBook()
  * @params mode, book
  * @description This method is used for open the dialog for book add and update with the help of mode and book data.
  * @author Ashish Hulwan
  */
  addUpdateBook(mode, book) {
    let data = {
      mode: mode,
      title: mode === "ADD" ? "Add New Book" : "Update Book Details",
      book: book
    }
    //Open the book dialog here
    let dialogRef = this.matDialog.open(BookDialogComponent, {
      data: data,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log("Book Add result=", result)
    });
  }

  /**
  * @function getAllBooks()
  * @param none
  * @description This method is used for getting all books present in databse and showing in ag-grid.
  * @author Ashish Hulwan
  */
  getAllBooks() {
    this.bookService.getBooks().subscribe(result => {
      this.books = result;

      //Update the row data using following method
      this.gridOptions.api.setRowData(this.createRowData(this.books));
      console.log("Books List=", result)
    })
  }

  /**
  * @function getMyBooks()
  * @param none
  * @description This method is used for getting users favourite books data by unique id that is user's email.
  * @author Ashish Hulwan
  */
  getMyBooks() {
    this.bookService.getMyBooks(this.user.email).subscribe(result => {
      this.myBooks = result;
      console.log("My Books List=", result)
    })
  }

  /**
  * @function deleteBook()
  * @param book
  * @description This method is used for deleting book data with confirmation dialog.
  * @author Ashish Hulwan
  */
  deleteBook(book) {
    /*  this.bookService.deleteBook(book.id).then(result => {
       console.log("Book deleted result=", result)
     }) */
    let data = {
      title: "Delete Book data",
      book: book
    }
    //Open dialog for delete book confirmation
    let dialogRef = this.matDialog.open(DeleteDialogComponent, {
      data: data,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        this.utilsService.showSnackBar("Your favourite book deleted successfully.")
      }
    });
  }
 
  /**
  * @function getAllCategories()
  * @param none
  * @description This method is used for getting all category list to show there display name in table.
  * @author Ashish Hulwan
  */
  getAllCategories() {
    this.categoryService.getCategories().subscribe(result => {
      this.categories = result;

      //Following grid method will update the coloumn defination for category display name.
      this.gridOptions.api.setColumnDefs(this.createColoumnDef(result));
      console.log("Castegory List=", result)
    })
  }

  /**
  * @function getNameFromCode()
  * @param code
  * @description This method is used for showing displyName for category code
  * @return displayName
  * @author Ashish Hulwan
  */
  getNameFromCode(code) {
    if (this.categories.length > 0) {
      return this.categories.filter(item => item.code === code)[0].displayName;
    } else {
      return code
    }
  }

  /**
  * @function callInConstructor()
  * @param code
  * @description This method is needs to call in constructor for initializting ag grid options
  * @author Ashish Hulwan
  */
  callInConstructor(categoryList) {
    this.gridOptions = <GridOptions>{
      rowData: this.createRowData(this.books),
      columnDefs: this.createColoumnDef(categoryList),
      onGridReady: () => {
        this.gridOptions.api.sizeColumnsToFit();
      },
      enableCellChangeFlash: true,
      defaultColDef: {
        resizable: true,
        editable: false
      },
      suppressRowTransform: true
    };
  }

  /**
  * @function createColoumnDef()
  * @param categories
  * @description This method is used for creating coloumn defination for grid
  * @returns coloumnDefination
  * @author Ashish Hulwan
  */
  createColoumnDef(categories) {
    return [
      {
        headerName: "Sr. No.",
        field: "id",
      },
      {
        headerName: "Book Bane",
        field: "name",
      },
      {
        headerName: "Author Name",
        field: "author",

      },
      {
        headerName: "Category",
        field: "category",
        valueGetter: function nameFromCode(params) {
          if (categories.length !== 0) {
            let nameArray = categories.filter(item => item.code === params.data.category);
            return nameArray[0].displayName;
          } else {
            return params.data.category;
          }
        },
        tooltip: function (params) {
          if (categories.length !== 0) {
            let nameArray = categories.filter(item => item.code === params.data.category);
            return nameArray[0].displayName;
          } else {
            return params.data.category;
          }
        },
      },
      {
        headerName: "Price",
        field: "price",
      },
      {
        headerName: "Publication",
        field: "publication",
      },
      {
        headerName: "description",
        field: "description",
      },


    ];
  }

  /**
  * @function createRowData()
  * @param books
  * @description This method is used for creating row data to display on ag grid
  * @returns rowData
  * @author Ashish Hulwan
  */
  createRowData(books) {
    let data = [];
    // debugger
    for (let i = 0; i < books.length; i++) {
      data.push({
        id: i + 1,
        name: books[i].name,
        author: books[i].author,
        category: books[i].category,
        price: books[i].price,
        publication: books[i].publication,
        description: books[i].description,
      })
    }
    console.log("ag grid row data===", data)
    return data;
  }

  /**
  * @function canDeactivate()
  * @param none
  * @description This method is triggered every time while you are changing routes. 
  * We can check here some unsaved data on the page then we can give a alert dialog to user. 
  * @returns rowData
  * @author Ashish Hulwan
  */
  canDeactivate() {
    return true;
    /* if (this.bookForm.dirty) {
      return window.confirm('You have unsaved data on this page. Click OK to leave page and continue, or Cancel to stay on page.');
    } else {
      return true
    } */
  }
}
