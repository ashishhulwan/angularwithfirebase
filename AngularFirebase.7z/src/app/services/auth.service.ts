import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { Router } from '@angular/router';

@Injectable()
export class AuthService {
    user: any
    constructor(public afAuth: AngularFireAuth, public router: Router) {
        this.afAuth.authState.subscribe(user => {
            if (user) {
                this.user = user;
                sessionStorage.setItem('USER', JSON.stringify(this.user));
            } else {
                sessionStorage.setItem('USER', null);
            }
        })
    }

    /**
     * @function login() logout()
     * @param none
     * @description This methods are used for login and logout user using firebase methods.
     * @author Ashish Hulwan
     */
    async login(data) {
        return await this.afAuth.auth.signInWithEmailAndPassword(data.email, data.password)
    }

    async logout() {
        return await this.afAuth.auth.signOut();
    }
}