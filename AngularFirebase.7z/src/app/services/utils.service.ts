import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
// import { SimpleModalService } from 'ngx-simple-modal';
// import { LoaderDialogComponent } from '../shared/loader/loader.dialog.component';
import { MatSnackBar } from '@angular/material';
import { Title, Meta } from '@angular/platform-browser';
import { AppConstants } from '../shared/constants';
// import { EncrDecrService } from './encr-decr.service';

@Injectable()

export class UtilsService {
  disposable: any;
  warningsArray: any[] = [];

  constructor(private router: Router, private snackBar: MatSnackBar, private titleService: Title, private meta: Meta, ) { }
  /**
  * @function isNonEmpty(), 
  * @param param
  * @description This function is used for checking the expected paramater is empty undefined or null, this function will be used for objects as well as strings
  * @author Ashish Hulwan
  * @returns this will return boolean value
  */
  isNonEmpty(param): boolean {
    if (param !== null && param !== undefined && param !== "")
      return true
    else
      return false
  }

  /**
  * @function smoothScrollToTop(), 
  * @param param
  * @description This function is used for scrolling to top with smooth behaviour.
  * @author Ashish Hulwan
  * @returns this will return boolean value
  */
  smoothScrollToTop() {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

/**
  * @function showSnackBar(), 
  * @param msg
  * @description This function is used showing snack bar message.
  * @author Ashish Hulwan
  * @returns this will return boolean value
  */
  showSnackBar(msg) {
    this.snackBar.open(msg, 'OK', {
      verticalPosition: 'top',
      horizontalPosition: 'center',
      duration: 3000
    });
  }

  /**
  * @function setTitleToPage(), addMetaTags()
  * @param title , metadata
  * @description This function is used Adding title and meta data to every page using title and meta service.
  * @author Ashish Hulwan
  */
  setTitleToPage(title) {
    return this.titleService.setTitle(title);
  }

  addMetaTags(metaData) {
    return this.meta.addTags(metaData);
  }

}