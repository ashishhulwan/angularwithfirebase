import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { LocationStrategy, PlatformLocation, Location } from '@angular/common';

@Injectable()


export class AuthenticatedGuard implements CanActivate {
  constructor(private router: Router, public location: Location) {
    console.log("I am in CanActivate constructor....", );
  }

  /**
  * @function canActivate()
  * @param none
  * @description This method is used chrecking user is logged in or not before accessing the desired routes.
  * @returns true/false
  * @author Ashish Hulwan
  */
  canActivate(): boolean {

    let userObj = JSON.parse(sessionStorage.getItem('USER'));
    console.log("=================", !!userObj);
    /* var titlee = this.location.path();
    console.log("=================", titlee); */

    if (!!userObj === false) {
      alert('You can not access these pages without login, Please login to proceed.')
      this.router.navigate(['login']);
      return false;
    }else{
      return true;
    }
  }

}