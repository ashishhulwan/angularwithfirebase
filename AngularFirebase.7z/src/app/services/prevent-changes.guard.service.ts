import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';

export interface CanComponentDeactivate {
  canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}
@Injectable()
export class PreventUnsavedChangesGuard implements CanDeactivate<CanComponentDeactivate> {
  /**
   * @function canDeactivate()
   * @param component
   * @description This method is used checking unsaved data is on component before changing the current route.
   * @author Ashish Hulwan
   */
  canDeactivate(component: CanComponentDeactivate) {
    return component.canDeactivate ? component.canDeactivate() : false;
  }
}