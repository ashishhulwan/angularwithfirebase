import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { map } from 'rxjs/operators';

@Injectable()
export class BookService {
    constructor(public db: AngularFirestore) {
        console.log("in ITRService component.........");

    }
    ngOnInit() { };

    /**
     * @function createBook()
     * @param none
     * @description This method is used creating book data in databse.
     * @author Ashish Hulwan
     */
    createBook(data) {
        return this.db.collection('books').add(data);
    }

    /**
     * @function getBooks()
     * @param none
     * @description This method is used getting all books data in array.
     * @returns All books data with document id added in response
     * @author Ashish Hulwan
     */
    getBooks() {
        return this.db.collection('books').snapshotChanges().pipe(
            map(actions => actions.map(a => {
                const data = a.payload.doc.data();
                const id = a.payload.doc.id;
                return { id, ...data };
            })))
    }

    /**
     * @function getBooks()
     * @param email
     * @description This method is used getting users favourite books data querying on email.
     * @returns User books data with document id added in response.
     * @author Ashish Hulwan
     */
    getMyBooks(email) {
        return this.db.collection('books',ref => ref.where('userEmail', '==', email)).snapshotChanges().pipe(
            map(actions => actions.map(a => {
                const data = a.payload.doc.data();
                const id = a.payload.doc.id;
                return { id, ...data };
            })))
    }
    
    /**
     * @function updateBook()
     * @param id, data
     * @description This method is used for update the book document using document id.
     * @author Ashish Hulwan
     */
    updateBook(id, data) {
        console.log("Data in update service", id, data)
      return this.db.collection('books').doc(id).update(data)
    }

    /**
     * @function deleteBook()
     * @param id
     * @description This method is used for deleting book record using book doc id.
     * @author Ashish Hulwan
     */
    deleteBook(id){
        return this.db.collection('books').doc(id).delete()
    }
}