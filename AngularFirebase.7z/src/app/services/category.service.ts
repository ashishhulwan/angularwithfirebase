import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { map } from 'rxjs/operators';

@Injectable()
export class CategoryService {
    constructor(public db: AngularFirestore) {

    }
    ngOnInit() { };

    /**
     * @function getCategories()
     * @param none
     * @description This method is used for getting category list from database.
     * @author Ashish Hulwan
     */
    getCategories() {
        return this.db.collection('categories').snapshotChanges().pipe(
            map(actions => actions.map(a => {
                const data = a.payload.doc.data();
                const id = a.payload.doc.id;
                return { id, ...data };
            })))
    }
}