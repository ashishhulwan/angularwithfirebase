import { Component, HostListener, AfterViewInit, Inject, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { BookService } from '../services/book.service';
import { Router } from '@angular/router';
import { Book } from '../shared/interfaces';
import { AppConstants } from '../shared/constants';
import { CategoryService } from '../services/category.service';
import { UtilsService } from '../services/utils.service';
declare let $: any;

@Component({
  selector: 'book-dialog',
  templateUrl: './book-dialog.component.html',
  styleUrls: ['./book-dialog.component.scss'],
  providers: [BookService]
})

export class BookDialogComponent implements OnInit {
  bookForm: FormGroup;
  bookDetails: Book;
  userData: any;
  charRegex = AppConstants.charRegex;
  categories = [];

  constructor(private utilsService: UtilsService, private fb: FormBuilder, private bookService: BookService, private router: Router, private categoryService: CategoryService,
    public dialogRef: MatDialogRef<BookDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.userData = JSON.parse(sessionStorage.getItem("USER"));
    //Book deatils object initialization
    this.bookDetails = {
      userEmail: this.userData.email,
      author: "",
      description: "",
      name: "",
      publication: "",
      price: null,
      category: "",
      comments: "",
    }

    //Call get all categories dropdown values
    this.getAllCategories()
  }

  /**
  * @function HostListener()
  * @param esc key
  * @description This function is used for closing dialog on esc key press.
  * @author Ashish Hulwan
  */
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  /**
  * @function ngOnInit()
  * @param none
  * @description This method is implemented from angular life cycle hooks for creating form group and setting values to form group in edit momde.
  * @author Ashish Hulwan
  */
  ngOnInit() {
    console.log("Data in on init===", this.data);
    this.bookForm = this.createBookForm();
    if (this.data.mode === "EDIT") {
      this.bookForm.patchValue(this.data.book);

    }
  }

  /**
  * @function createBookForm()
  * @param none
  * @description This function is used for generating book form with applied validations.
  * @return bookForm
  * @author Ashish Hulwan
  */
  createBookForm(): FormGroup {
    return this.fb.group({
      description: ["", Validators.required],
      name: ["", [Validators.required]],
      author: ["", Validators.compose([Validators.required, Validators.pattern(this.charRegex)])],
      publication: [""],
      price: [null, Validators.required],
      category: ["", Validators.required],
      comments: [""],
    })
  }

  /**
  * @function save()
  * @param none
  * @description This function is used for saveing data to database or update the data in edit mode.
  * @author Ashish Hulwan
  */
  save() {
    // debugger
    if (this.bookForm.valid) {
      // console.log("Book Details", this.bookForm.getRawValue(), "id", this.data.book);

      //This will assign all values from form group to book details object which keys are matched
      Object.assign(this.bookDetails, this.bookForm.getRawValue());
      console.log("Book Details", this.bookDetails);
      if (this.data.mode === "ADD") {
        this.bookService.createBook(this.bookDetails)
          .then(res => {
            this.utilsService.showSnackBar("Your favourite book added successfuly.");
            this.dialogRef.close(true);
          })
      } else {
        this.bookService.updateBook(this.data.book.id, this.bookForm.getRawValue())
          .then(res => {
            this.utilsService.showSnackBar("Your favourite book added successfuly.");
            this.dialogRef.close(true);
          })
      }
    } else {
      //Setting focous to first invalid feild if bookForm group is invalid.
      $('input.ng-invalid').first().focus();
    }
  }

  categorySelected() {
    console.log("Category selected", this.bookForm)
  }

  /**
  * @function getAllCategories()
  * @param none
  * @description This function is used for getting category list and showing in dropdown.
  * @author Ashish Hulwan
  */
  getAllCategories() {
    this.categoryService.getCategories().subscribe(result => {
      this.categories = result;
      console.log("Castegory List=", result);

      //By using sort function category list is sorted in ascending order by displayName property.
      this.categories.sort(function (a: any, b: any) {
        if (a.displayName < b.displayName)
          return -1;

        if (a.displayName > b.displayName)
          return 1;

        return 0
      });
    })
  }
}