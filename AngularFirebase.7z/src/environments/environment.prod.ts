export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyAF2axwjkxeqiooLEhuNtmEv-dyA-gO2MI',
    authDomain: 'angularwithfirebase-988f4.firebaseapp.com',
    databaseURL: 'https://angularwithfirebase-988f4.firebaseio.com',
    projectId: 'angularwithfirebase-988f4',
    storageBucket: 'angularwithfirebase-988f4.appspot.com',
    messagingSenderId: '169306023655'
}
};
